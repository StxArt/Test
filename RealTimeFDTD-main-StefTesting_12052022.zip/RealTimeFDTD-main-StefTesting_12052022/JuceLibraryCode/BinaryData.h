/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   _03MetalBox_Hammer_wav;
    const int            _03MetalBox_Hammer_wavSize = 372286;

    extern const char*   AcGuitarHammerMix_wav;
    const int            AcGuitarHammerMix_wavSize = 45524;

    extern const char*   AcGuitarSweepMix_wav;
    const int            AcGuitarSweepMix_wavSize = 45524;

    extern const char*   cassette_recorder_wav;
    const int            cassette_recorder_wavSize = 37902;

    extern const char*   guitar_amp_wav;
    const int            guitar_amp_wavSize = 90246;

    extern const char*   reverb_ir_wav;
    const int            reverb_ir_wavSize = 648404;

    extern const char*   Space4ArtGallery_wav;
    const int            Space4ArtGallery_wavSize = 442652;

    extern const char*   violinNylonStrings_jpg;
    const int            violinNylonStrings_jpgSize = 27223;

    extern const char*   Alurohr_jpg;
    const int            Alurohr_jpgSize = 40718;

    extern const char*   Geige_jpg;
    const int            Geige_jpgSize = 22200;

    extern const char*   Westerngitarre_jpg;
    const int            Westerngitarre_jpgSize = 21209;

    extern const char*   Glockenspiel_jpg;
    const int            Glockenspiel_jpgSize = 23940;

    extern const char*   guitarwithoutstrings_jpg;
    const int            guitarwithoutstrings_jpgSize = 54546;

    extern const char*   Holzbox_jpg;
    const int            Holzbox_jpgSize = 13506;

    extern const char*   Metallbox_jpg;
    const int            Metallbox_jpgSize = 127599;

    extern const char*   Pappkarton_jpeg;
    const int            Pappkarton_jpegSize = 51737;

    extern const char*   violineWithoutStrings_jpg;
    const int            violineWithoutStrings_jpgSize = 288763;

    extern const char*   Xylophon_jpg;
    const int            Xylophon_jpgSize = 37378;

    extern const char*   GuitarNylonStrings_jpg;
    const int            GuitarNylonStrings_jpgSize = 21713;

    extern const char*   MetalBar_jpg;
    const int            MetalBar_jpgSize = 9682;

    extern const char*   WoodenBar_jpg;
    const int            WoodenBar_jpgSize = 35967;

    extern const char*   GuitarOnlyStrings_jpg;
    const int            GuitarOnlyStrings_jpgSize = 19518;

    extern const char*   ViolinOnlyStrings_jpg;
    const int            ViolinOnlyStrings_jpgSize = 30106;

    // Number of elements in the namedResourceList and originalFileNames arrays.
    const int namedResourceListSize = 23;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Points to the start of a list of resource filenames.
    extern const char* originalFilenames[];

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes);

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding original, non-mangled filename (or a null pointer if the name isn't found).
    const char* getNamedResourceOriginalFilename (const char* resourceNameUTF8);
}
